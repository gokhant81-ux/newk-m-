import { useState } from 'react';
import { 
  Search, 
  Plus, 
  Phone, 
  Mail, 
  MapPin, 
  Edit2, 
  Trash2, 
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useStore } from '@/hooks/useStore';
import { formatCurrency, formatDate } from '@/lib/utils';
import { toast } from 'sonner';
import type { Customer } from '@/types';

export function CustomersPage() {
  const { customers, addCustomer, updateCustomer, deleteCustomer, searchCustomers, getCustomerOrders } = useStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  
  // Form state
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    address: '',
    notes: '',
  });

  const filteredCustomers = searchQuery ? searchCustomers(searchQuery) : customers;

  const handleAddCustomer = () => {
    if (!formData.firstName || !formData.lastName || !formData.phone) {
      toast.error('Lütfen zorunlu alanları doldurun');
      return;
    }

    addCustomer(formData);
    toast.success('Müşteri başarıyla eklendi');
    setIsAddDialogOpen(false);
    resetForm();
  };

  const handleUpdateCustomer = () => {
    if (!selectedCustomer) return;
    
    if (!formData.firstName || !formData.lastName || !formData.phone) {
      toast.error('Lütfen zorunlu alanları doldurun');
      return;
    }

    updateCustomer(selectedCustomer.id, formData);
    toast.success('Müşteri başarıyla güncellendi');
    setIsEditDialogOpen(false);
    setSelectedCustomer(null);
    resetForm();
  };

  const handleDeleteCustomer = (customer: Customer) => {
    if (confirm(`${customer.firstName} ${customer.lastName} isimli müşteriyi silmek istediğinize emin misiniz?`)) {
      deleteCustomer(customer.id);
      toast.success('Müşteri silindi');
    }
  };

  const openEditDialog = (customer: Customer) => {
    setSelectedCustomer(customer);
    setFormData({
      firstName: customer.firstName,
      lastName: customer.lastName,
      phone: customer.phone,
      email: customer.email || '',
      address: customer.address || '',
      notes: customer.notes || '',
    });
    setIsEditDialogOpen(true);
  };

  const openDetailDialog = (customer: Customer) => {
    setSelectedCustomer(customer);
    setIsDetailDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      firstName: '',
      lastName: '',
      phone: '',
      email: '',
      address: '',
      notes: '',
    });
  };

  const customerOrders = selectedCustomer ? getCustomerOrders(selectedCustomer.id) : [];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Müşteriler</h1>
          <p className="text-slate-500">Müşteri listesi ve yönetimi</p>
        </div>
        <Button 
          className="bg-blue-600 hover:bg-blue-700"
          onClick={() => {
            resetForm();
            setIsAddDialogOpen(true);
          }}
        >
          <Plus className="w-4 h-4 mr-2" />
          Yeni Müşteri
        </Button>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input
              placeholder="Müşteri ara (isim, telefon...)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Customers Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50">
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Müşteri</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">İletişim</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Sipariş</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Toplam Harcama</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Bakiye</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">İşlemler</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map((customer) => (
                  <tr 
                    key={customer.id} 
                    className="border-b border-slate-50 hover:bg-slate-50 transition-colors cursor-pointer"
                    onClick={() => openDetailDialog(customer)}
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <span className="text-blue-600 font-medium">
                            {customer.firstName[0]}{customer.lastName[0]}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium text-slate-800">{customer.firstName} {customer.lastName}</p>
                          <p className="text-sm text-slate-500">{formatDate(customer.createdAt)}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm text-slate-600">
                          <Phone className="w-4 h-4" />
                          {customer.phone}
                        </div>
                        {customer.email && (
                          <div className="flex items-center gap-2 text-sm text-slate-600">
                            <Mail className="w-4 h-4" />
                            {customer.email}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <Badge variant="secondary">
                        {customer.totalOrders} sipariş
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-800">
                        {formatCurrency(customer.totalSpent)}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`font-medium ${customer.balance > 0 ? 'text-red-600' : 'text-green-600'}`}>
                        {formatCurrency(customer.balance)}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEditDialog(customer)}
                        >
                          <Edit2 className="w-4 h-4 text-slate-500" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteCustomer(customer)}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredCustomers.length === 0 && (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400">
                      {searchQuery ? 'Arama sonucu bulunamadı' : 'Henüz müşteri bulunmuyor'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add Customer Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Yeni Müşteri Ekle</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">Ad *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  placeholder="Ad"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Soyad *</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  placeholder="Soyad"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Telefon *</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="05XX XXX XX XX"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">E-posta</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="ornek@email.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Adres</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="Adres bilgisi"
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notlar</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Müşteri hakkında notlar..."
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              İptal
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleAddCustomer}>
              Kaydet
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Customer Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Müşteri Düzenle</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-firstName">Ad *</Label>
                <Input
                  id="edit-firstName"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-lastName">Soyad *</Label>
                <Input
                  id="edit-lastName"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-phone">Telefon *</Label>
              <Input
                id="edit-phone"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-email">E-posta</Label>
              <Input
                id="edit-email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-address">Adres</Label>
              <Textarea
                id="edit-address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-notes">Notlar</Label>
              <Textarea
                id="edit-notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              İptal
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleUpdateCustomer}>
              Güncelle
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Customer Detail Dialog */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          {selectedCustomer && (
            <>
              <DialogHeader>
                <div className="flex items-center justify-between">
                  <DialogTitle className="text-xl">Müşteri Detayı</DialogTitle>
                  <Button variant="ghost" size="icon" onClick={() => setIsDetailDialogOpen(false)}>
                    <X className="w-5 h-5" />
                  </Button>
                </div>
              </DialogHeader>
              
              <div className="space-y-6 py-4">
                {/* Customer Info */}
                <div className="flex items-start gap-4">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-blue-600 font-bold text-xl">
                      {selectedCustomer.firstName[0]}{selectedCustomer.lastName[0]}
                    </span>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-slate-800">
                      {selectedCustomer.firstName} {selectedCustomer.lastName}
                    </h3>
                    <p className="text-slate-500">Müşteri since {formatDate(selectedCustomer.createdAt)}</p>
                    
                    <div className="grid grid-cols-3 gap-4 mt-4">
                      <div className="bg-slate-50 p-3 rounded-lg text-center">
                        <p className="text-2xl font-bold text-slate-800">{selectedCustomer.totalOrders}</p>
                        <p className="text-sm text-slate-500">Sipariş</p>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-lg text-center">
                        <p className="text-2xl font-bold text-green-600">{formatCurrency(selectedCustomer.totalSpent)}</p>
                        <p className="text-sm text-slate-500">Toplam</p>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-lg text-center">
                        <p className={`text-2xl font-bold ${selectedCustomer.balance > 0 ? 'text-red-600' : 'text-green-600'}`}>
                          {formatCurrency(selectedCustomer.balance)}
                        </p>
                        <p className="text-sm text-slate-500">Bakiye</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Contact Info */}
                <div className="border-t border-slate-100 pt-4">
                  <h4 className="font-semibold text-slate-800 mb-3">İletişim Bilgileri</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-3 text-slate-600">
                      <Phone className="w-5 h-5 text-slate-400" />
                      {selectedCustomer.phone}
                    </div>
                    {selectedCustomer.email && (
                      <div className="flex items-center gap-3 text-slate-600">
                        <Mail className="w-5 h-5 text-slate-400" />
                        {selectedCustomer.email}
                      </div>
                    )}
                    {selectedCustomer.address && (
                      <div className="flex items-center gap-3 text-slate-600">
                        <MapPin className="w-5 h-5 text-slate-400" />
                        {selectedCustomer.address}
                      </div>
                    )}
                  </div>
                </div>

                {/* Notes */}
                {selectedCustomer.notes && (
                  <div className="border-t border-slate-100 pt-4">
                    <h4 className="font-semibold text-slate-800 mb-2">Notlar</h4>
                    <p className="text-slate-600 bg-slate-50 p-3 rounded-lg">
                      {selectedCustomer.notes}
                    </p>
                  </div>
                )}

                {/* Order History */}
                <div className="border-t border-slate-100 pt-4">
                  <h4 className="font-semibold text-slate-800 mb-3">Sipariş Geçmişi</h4>
                  {customerOrders.length > 0 ? (
                    <div className="space-y-2">
                      {customerOrders.slice(0, 5).map((order) => (
                        <div key={order.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                          <div>
                            <p className="font-medium text-slate-800">#{order.orderNumber}</p>
                            <p className="text-sm text-slate-500">{formatDate(order.createdAt)}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium text-slate-800">{formatCurrency(order.finalAmount)}</p>
                            <p className="text-sm text-slate-500">{order.items.length} ürün</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-400 text-center py-4">Henüz sipariş bulunmuyor</p>
                  )}
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDetailDialogOpen(false)}>
                  Kapat
                </Button>
                <Button 
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={() => {
                    setIsDetailDialogOpen(false);
                    openEditDialog(selectedCustomer);
                  }}
                >
                  <Edit2 className="w-4 h-4 mr-2" />
                  Düzenle
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
