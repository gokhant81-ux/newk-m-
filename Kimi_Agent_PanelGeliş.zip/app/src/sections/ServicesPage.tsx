import { useState } from 'react';
import { 
  Search, 
  Plus, 
  Edit2, 
  Trash2, 
  Sparkles,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useStore } from '@/hooks/useStore';
import { formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';
import type { Service } from '@/types';

const categories = [
  'Yıkama',
  'Kuru Temizleme',
  'Ev Tekstili',
  'Ütü',
  'Tamir',
  'Diğer',
];

const units = [
  { value: 'adet', label: 'Adet' },
  { value: 'kg', label: 'Kilogram' },
  { value: 'metre', label: 'Metre' },
];

export function ServicesPage() {
  const { services, addService, updateService, deleteService } = useStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  
  const [formData, setFormData] = useState<{
    name: string;
    category: string;
    price: number;
    unit: 'adet' | 'kg' | 'metre';
    description: string;
    estimatedDays: number;
    isActive: boolean;
  }>({
    name: '',
    category: '',
    price: 0,
    unit: 'adet',
    description: '',
    estimatedDays: 1,
    isActive: true,
  });

  const filteredServices = services.filter((service) =>
    service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    service.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const servicesByCategory = categories.map((category) => ({
    category,
    services: filteredServices.filter((s) => s.category === category),
  })).filter((group) => group.services.length > 0);

  const handleAddService = () => {
    if (!formData.name || !formData.category || formData.price <= 0) {
      toast.error('Lütfen zorunlu alanları doldurun');
      return;
    }

    addService(formData);
    toast.success('Hizmet başarıyla eklendi');
    setIsAddDialogOpen(false);
    resetForm();
  };

  const handleUpdateService = () => {
    if (!selectedService) return;
    
    if (!formData.name || !formData.category || formData.price <= 0) {
      toast.error('Lütfen zorunlu alanları doldurun');
      return;
    }

    updateService(selectedService.id, formData);
    toast.success('Hizmet başarıyla güncellendi');
    setIsEditDialogOpen(false);
    setSelectedService(null);
    resetForm();
  };

  const handleDeleteService = (service: Service) => {
    if (confirm(`${service.name} hizmetini silmek istediğinize emin misiniz?`)) {
      deleteService(service.id);
      toast.success('Hizmet silindi');
    }
  };

  const openEditDialog = (service: Service) => {
    setSelectedService(service);
    setFormData({
      name: service.name,
      category: service.category,
      price: service.price,
      unit: service.unit,
      description: service.description || '',
      estimatedDays: service.estimatedDays,
      isActive: service.isActive,
    });
    setIsEditDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      category: '',
      price: 0,
      unit: 'adet',
      description: '',
      estimatedDays: 1,
      isActive: true,
    });
  };

  const toggleServiceStatus = (service: Service) => {
    updateService(service.id, { isActive: !service.isActive });
    toast.success(service.isActive ? 'Hizmet pasifleştirildi' : 'Hizmet aktifleştirildi');
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Hizmetler</h1>
          <p className="text-slate-500">Hizmet ve fiyat yönetimi</p>
        </div>
        <Button 
          className="bg-blue-600 hover:bg-blue-700"
          onClick={() => {
            resetForm();
            setIsAddDialogOpen(true);
          }}
        >
          <Plus className="w-4 h-4 mr-2" />
          Yeni Hizmet
        </Button>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input
              placeholder="Hizmet ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Services by Category */}
      <div className="space-y-6">
        {servicesByCategory.map(({ category, services }) => (
          <Card key={category}>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-blue-500" />
                {category}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50">
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Hizmet Adı</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Fiyat</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Birim</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Süre</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Durum</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">İşlemler</th>
                    </tr>
                  </thead>
                  <tbody>
                    {services.map((service) => (
                      <tr key={service.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                        <td className="py-3 px-4">
                          <div>
                            <p className="font-medium text-slate-800">{service.name}</p>
                            {service.description && (
                              <p className="text-sm text-slate-500">{service.description}</p>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-medium text-slate-800">{formatCurrency(service.price)}</span>
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant="outline">{service.unit}</Badge>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2 text-sm text-slate-600">
                            <Clock className="w-4 h-4" />
                            {service.estimatedDays} gün
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <Switch
                              checked={service.isActive}
                              onCheckedChange={() => toggleServiceStatus(service)}
                            />
                            <span className={`text-sm ${service.isActive ? 'text-green-600' : 'text-slate-400'}`}>
                              {service.isActive ? 'Aktif' : 'Pasif'}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => openEditDialog(service)}
                            >
                              <Edit2 className="w-4 h-4 text-slate-500" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteService(service)}
                            >
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        ))}

        {servicesByCategory.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center">
              <Sparkles className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">
                {searchQuery ? 'Arama sonucu bulunamadı' : 'Henüz hizmet bulunmuyor'}
              </p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Add Service Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Yeni Hizmet Ekle</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Hizmet Adı *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Örn: Gömlek Yıkama"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category">Kategori *</Label>
              <Select value={formData.category} onValueChange={(v) => setFormData({ ...formData, category: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Kategori seçin" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="price">Fiyat (₺) *</Label>
                <Input
                  id="price"
                  type="number"
                  min={0}
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: parseInt(e.target.value) || 0 })}
                  placeholder="0"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="unit">Birim</Label>
                <Select value={formData.unit} onValueChange={(v: any) => setFormData({ ...formData, unit: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {units.map((u) => (
                      <SelectItem key={u.value} value={u.value}>{u.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="estimatedDays">Tahmini Süre (gün)</Label>
              <Input
                id="estimatedDays"
                type="number"
                min={1}
                value={formData.estimatedDays}
                onChange={(e) => setFormData({ ...formData, estimatedDays: parseInt(e.target.value) || 1 })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Açıklama</Label>
              <Input
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Hizmet açıklaması..."
              />
            </div>
            <div className="flex items-center gap-2">
              <Switch
                checked={formData.isActive}
                onCheckedChange={(v) => setFormData({ ...formData, isActive: v })}
              />
              <Label>Aktif</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              İptal
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleAddService}>
              Kaydet
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Service Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Hizmet Düzenle</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Hizmet Adı *</Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-category">Kategori *</Label>
              <Select value={formData.category} onValueChange={(v) => setFormData({ ...formData, category: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-price">Fiyat (₺) *</Label>
                <Input
                  id="edit-price"
                  type="number"
                  min={0}
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: parseInt(e.target.value) || 0 })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-unit">Birim</Label>
                <Select value={formData.unit} onValueChange={(v: any) => setFormData({ ...formData, unit: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {units.map((u) => (
                      <SelectItem key={u.value} value={u.value}>{u.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-estimatedDays">Tahmini Süre (gün)</Label>
              <Input
                id="edit-estimatedDays"
                type="number"
                min={1}
                value={formData.estimatedDays}
                onChange={(e) => setFormData({ ...formData, estimatedDays: parseInt(e.target.value) || 1 })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">Açıklama</Label>
              <Input
                id="edit-description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
            </div>
            <div className="flex items-center gap-2">
              <Switch
                checked={formData.isActive}
                onCheckedChange={(v) => setFormData({ ...formData, isActive: v })}
              />
              <Label>Aktif</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              İptal
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleUpdateService}>
              Güncelle
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
