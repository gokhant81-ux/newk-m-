import { useState, useMemo } from 'react';
import { 
  Search, 
  Plus, 
  Filter, 
  MoreHorizontal,
  Calendar,
  User,
  Package,
  Trash2,
  X,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useStore } from '@/hooks/useStore';
import { formatCurrency, formatDate, getStatusLabel, getStatusColor } from '@/lib/utils';
import { toast } from 'sonner';
import type { Order, OrderStatus, OrderItem } from '@/types';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

const statusFlow: OrderStatus[] = ['pending', 'washing', 'ironing', 'ready', 'delivered'];

export function OrdersPage() {
  const { 
    orders, 
    customers, 
    services, 
    addOrder, 
    deleteOrder, 
    updateOrderStatus,
    getCustomerById 
  } = useStore();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  
  // New order form state
  const [newOrder, setNewOrder] = useState({
    customerId: '',
    items: [] as OrderItem[],
    discount: 0,
    notes: '',
    promisedDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  });
  
  const [selectedService, setSelectedService] = useState('');
  const [selectedQuantity, setSelectedQuantity] = useState(1);

  const filteredOrders = useMemo(() => {
    let result = [...orders].sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    if (statusFilter !== 'all') {
      result = result.filter(o => o.status === statusFilter);
    }
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(o => 
        o.orderNumber.toLowerCase().includes(query) ||
        o.customerName.toLowerCase().includes(query) ||
        o.customerPhone.includes(query)
      );
    }
    
    return result;
  }, [orders, statusFilter, searchQuery]);

  const handleAddItem = () => {
    if (!selectedService) return;
    
    const service = services.find(s => s.id === selectedService);
    if (!service) return;
    
    const newItem: OrderItem = {
      id: `item-${Date.now()}`,
      serviceId: service.id,
      serviceName: service.name,
      quantity: selectedQuantity,
      unitPrice: service.price,
      totalPrice: service.price * selectedQuantity,
    };
    
    setNewOrder({
      ...newOrder,
      items: [...newOrder.items, newItem],
    });
    
    setSelectedService('');
    setSelectedQuantity(1);
  };

  const handleRemoveItem = (itemId: string) => {
    setNewOrder({
      ...newOrder,
      items: newOrder.items.filter(i => i.id !== itemId),
    });
  };

  const calculateTotals = () => {
    const totalAmount = newOrder.items.reduce((sum, item) => sum + item.totalPrice, 0);
    const finalAmount = totalAmount - newOrder.discount;
    return { totalAmount, finalAmount };
  };

  const handleCreateOrder = () => {
    if (!newOrder.customerId) {
      toast.error('Lütfen müşteri seçin');
      return;
    }
    
    if (newOrder.items.length === 0) {
      toast.error('Lütfen en az bir ürün ekleyin');
      return;
    }
    
    const customer = getCustomerById(newOrder.customerId);
    if (!customer) return;
    
    const { totalAmount, finalAmount } = calculateTotals();
    
    addOrder({
      customerId: customer.id,
      customerName: `${customer.firstName} ${customer.lastName}`,
      customerPhone: customer.phone,
      items: newOrder.items,
      totalAmount,
      discount: newOrder.discount,
      finalAmount,
      paidAmount: 0,
      remainingAmount: finalAmount,
      status: 'pending',
      notes: newOrder.notes,
      promisedDate: new Date(newOrder.promisedDate).toISOString(),
    });
    
    toast.success('Sipariş başarıyla oluşturuldu');
    setIsAddDialogOpen(false);
    resetNewOrder();
  };

  const resetNewOrder = () => {
    setNewOrder({
      customerId: '',
      items: [],
      discount: 0,
      notes: '',
      promisedDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    });
    setSelectedService('');
    setSelectedQuantity(1);
  };

  const handleStatusChange = (order: Order, newStatus: OrderStatus) => {
    updateOrderStatus(order.id, newStatus);
    toast.success(`Sipariş durumu güncellendi: ${getStatusLabel(newStatus)}`);
  };

  const handleDeleteOrder = (order: Order) => {
    if (confirm(`Sipariş #${order.orderNumber} silinecek. Emin misiniz?`)) {
      deleteOrder(order.id);
      toast.success('Sipariş silindi');
    }
  };

  const openDetailDialog = (order: Order) => {
    setSelectedOrder(order);
    setIsDetailDialogOpen(true);
  };

  const getNextStatus = (currentStatus: OrderStatus): OrderStatus | null => {
    const currentIndex = statusFlow.indexOf(currentStatus);
    if (currentIndex < statusFlow.length - 1 && currentStatus !== 'cancelled') {
      return statusFlow[currentIndex + 1];
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Siparişler</h1>
          <p className="text-slate-500">Sipariş yönetimi ve takibi</p>
        </div>
        <Button 
          className="bg-blue-600 hover:bg-blue-700"
          onClick={() => {
            resetNewOrder();
            setIsAddDialogOpen(true);
          }}
        >
          <Plus className="w-4 h-4 mr-2" />
          Yeni Sipariş
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input
                placeholder="Sipariş ara (no, müşteri...)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as OrderStatus | 'all')}>
              <SelectTrigger className="w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Durum filtresi" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tümü</SelectItem>
                <SelectItem value="pending">Beklemede</SelectItem>
                <SelectItem value="washing">Yıkamada</SelectItem>
                <SelectItem value="ironing">Ütüde</SelectItem>
                <SelectItem value="ready">Hazır</SelectItem>
                <SelectItem value="delivered">Teslim Edildi</SelectItem>
                <SelectItem value="cancelled">İptal Edildi</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Status Tabs */}
      <Tabs value={statusFilter} onValueChange={(v) => setStatusFilter(v as OrderStatus | 'all')}>
        <TabsList className="grid grid-cols-7 w-full">
          <TabsTrigger value="all">Tümü</TabsTrigger>
          <TabsTrigger value="pending">Beklemede</TabsTrigger>
          <TabsTrigger value="washing">Yıkamada</TabsTrigger>
          <TabsTrigger value="ironing">Ütüde</TabsTrigger>
          <TabsTrigger value="ready">Hazır</TabsTrigger>
          <TabsTrigger value="delivered">Teslim</TabsTrigger>
          <TabsTrigger value="cancelled">İptal</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Orders Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50">
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Sipariş No</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Müşteri</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Ürünler</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Tutar</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Durum</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Teslim Tarihi</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">İşlemler</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.map((order) => (
                  <tr 
                    key={order.id} 
                    className="border-b border-slate-50 hover:bg-slate-50 transition-colors"
                  >
                    <td className="py-3 px-4">
                      <button 
                        onClick={() => openDetailDialog(order)}
                        className="font-medium text-blue-600 hover:text-blue-700"
                      >
                        #{order.orderNumber}
                      </button>
                    </td>
                    <td className="py-3 px-4">
                      <div>
                        <p className="font-medium text-slate-800">{order.customerName}</p>
                        <p className="text-sm text-slate-500">{order.customerPhone}</p>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="space-y-1">
                        {order.items.slice(0, 2).map((item, idx) => (
                          <p key={idx} className="text-sm text-slate-600">
                            {item.quantity}x {item.serviceName}
                          </p>
                        ))}
                        {order.items.length > 2 && (
                          <p className="text-sm text-slate-400">+{order.items.length - 2} daha</p>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div>
                        <p className="font-medium text-slate-800">{formatCurrency(order.finalAmount)}</p>
                        {order.remainingAmount > 0 && (
                          <p className="text-sm text-red-500">
                            {formatCurrency(order.remainingAmount)} borç
                          </p>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <Badge className={getStatusColor(order.status)}>
                        {getStatusLabel(order.status)}
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <Calendar className="w-4 h-4" />
                        {formatDate(order.promisedDate)}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        {getNextStatus(order.status) && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleStatusChange(order, getNextStatus(order.status)!)}
                          >
                            <ChevronRight className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openDetailDialog(order)}
                        >
                          <MoreHorizontal className="w-4 h-4 text-slate-500" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteOrder(order)}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredOrders.length === 0 && (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      {searchQuery || statusFilter !== 'all' ? 'Sonuç bulunamadı' : 'Henüz sipariş bulunmuyor'}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add Order Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Yeni Sipariş Oluştur</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* Customer Selection */}
            <div className="space-y-2">
              <Label>Müşteri *</Label>
              <Select value={newOrder.customerId} onValueChange={(v) => setNewOrder({ ...newOrder, customerId: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Müşteri seçin" />
                </SelectTrigger>
                <SelectContent>
                  {customers.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.firstName} {customer.lastName} - {customer.phone}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Add Items */}
            <div className="space-y-4 border rounded-lg p-4">
              <Label>Hizmet Ekle</Label>
              <div className="flex gap-4">
                <Select value={selectedService} onValueChange={setSelectedService}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Hizmet seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {services.filter(s => s.isActive).map((service) => (
                      <SelectItem key={service.id} value={service.id}>
                        {service.name} - {formatCurrency(service.price)}/{service.unit}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  type="number"
                  min={1}
                  value={selectedQuantity}
                  onChange={(e) => setSelectedQuantity(parseInt(e.target.value) || 1)}
                  className="w-24"
                />
                <Button type="button" onClick={handleAddItem} disabled={!selectedService}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>

              {/* Items List */}
              {newOrder.items.length > 0 && (
                <div className="space-y-2 mt-4">
                  {newOrder.items.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                      <span className="text-sm">{item.quantity}x {item.serviceName}</span>
                      <div className="flex items-center gap-3">
                        <span className="font-medium">{formatCurrency(item.totalPrice)}</span>
                        <Button variant="ghost" size="sm" onClick={() => handleRemoveItem(item.id)}>
                          <X className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Discount */}
            <div className="space-y-2">
              <Label>İndirim (₺)</Label>
              <Input
                type="number"
                min={0}
                value={newOrder.discount}
                onChange={(e) => setNewOrder({ ...newOrder, discount: parseInt(e.target.value) || 0 })}
              />
            </div>

            {/* Promised Date */}
            <div className="space-y-2">
              <Label>Teslim Tarihi *</Label>
              <Input
                type="date"
                value={newOrder.promisedDate}
                onChange={(e) => setNewOrder({ ...newOrder, promisedDate: e.target.value })}
              />
            </div>

            {/* Notes */}
            <div className="space-y-2">
              <Label>Notlar</Label>
              <Textarea
                value={newOrder.notes}
                onChange={(e) => setNewOrder({ ...newOrder, notes: e.target.value })}
                placeholder="Sipariş hakkında notlar..."
                rows={2}
              />
            </div>

            {/* Summary */}
            <div className="border-t pt-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Ara Toplam:</span>
                  <span>{formatCurrency(calculateTotals().totalAmount)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">İndirim:</span>
                  <span className="text-red-500">-{formatCurrency(newOrder.discount)}</span>
                </div>
                <div className="flex justify-between text-lg font-bold pt-2 border-t">
                  <span>Toplam:</span>
                  <span className="text-blue-600">{formatCurrency(calculateTotals().finalAmount)}</span>
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              İptal
            </Button>
            <Button 
              className="bg-blue-600 hover:bg-blue-700" 
              onClick={handleCreateOrder}
              disabled={newOrder.items.length === 0 || !newOrder.customerId}
            >
              Sipariş Oluştur
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Order Detail Dialog */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          {selectedOrder && (
            <>
              <DialogHeader>
                <div className="flex items-center justify-between">
                  <DialogTitle className="text-xl">Sipariş #{selectedOrder.orderNumber}</DialogTitle>
                  <Button variant="ghost" size="icon" onClick={() => setIsDetailDialogOpen(false)}>
                    <X className="w-5 h-5" />
                  </Button>
                </div>
              </DialogHeader>
              
              <div className="space-y-6 py-4">
                {/* Status Badge */}
                <div className="flex items-center justify-between">
                  <Badge className={`${getStatusColor(selectedOrder.status)} text-sm px-3 py-1`}>
                    {getStatusLabel(selectedOrder.status)}
                  </Badge>
                  <span className="text-sm text-slate-500">
                    {formatDate(selectedOrder.createdAt)}
                  </span>
                </div>

                {/* Customer Info */}
                <div className="bg-slate-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-slate-800 mb-2">Müşteri Bilgileri</h4>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <User className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-800">{selectedOrder.customerName}</p>
                      <p className="text-sm text-slate-500">{selectedOrder.customerPhone}</p>
                    </div>
                  </div>
                </div>

                {/* Items */}
                <div>
                  <h4 className="font-semibold text-slate-800 mb-3">Sipariş Detayı</h4>
                  <div className="space-y-2">
                    {selectedOrder.items.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <Package className="w-5 h-5 text-slate-400" />
                          <span>{item.quantity}x {item.serviceName}</span>
                        </div>
                        <span className="font-medium">{formatCurrency(item.totalPrice)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Summary */}
                <div className="border-t pt-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500">Ara Toplam:</span>
                      <span>{formatCurrency(selectedOrder.totalAmount)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500">İndirim:</span>
                      <span className="text-red-500">-{formatCurrency(selectedOrder.discount)}</span>
                    </div>
                    <div className="flex justify-between text-lg font-bold pt-2 border-t">
                      <span>Toplam:</span>
                      <span className="text-blue-600">{formatCurrency(selectedOrder.finalAmount)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500">Ödenen:</span>
                      <span className="text-green-600">{formatCurrency(selectedOrder.paidAmount)}</span>
                    </div>
                    {selectedOrder.remainingAmount > 0 && (
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-500">Kalan:</span>
                        <span className="text-red-600 font-medium">{formatCurrency(selectedOrder.remainingAmount)}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Notes */}
                {selectedOrder.notes && (
                  <div className="border-t pt-4">
                    <h4 className="font-semibold text-slate-800 mb-2">Notlar</h4>
                    <p className="text-slate-600 bg-slate-50 p-3 rounded-lg">{selectedOrder.notes}</p>
                  </div>
                )}

                {/* Status Actions */}
                <div className="border-t pt-4">
                  <h4 className="font-semibold text-slate-800 mb-3">Durum Güncelle</h4>
                  <div className="flex flex-wrap gap-2">
                    {statusFlow.map((status) => (
                      <Button
                        key={status}
                        size="sm"
                        variant={selectedOrder.status === status ? 'default' : 'outline'}
                        onClick={() => handleStatusChange(selectedOrder, status)}
                        disabled={selectedOrder.status === status || selectedOrder.status === 'cancelled'}
                        className={selectedOrder.status === status ? 'bg-blue-600' : ''}
                      >
                        {getStatusLabel(status)}
                      </Button>
                    ))}
                    <Button
                      size="sm"
                      variant={selectedOrder.status === 'cancelled' ? 'default' : 'outline'}
                      onClick={() => handleStatusChange(selectedOrder, 'cancelled')}
                      disabled={selectedOrder.status === 'cancelled'}
                      className={selectedOrder.status === 'cancelled' ? 'bg-red-600' : 'text-red-600 hover:bg-red-50'}
                    >
                      İptal Et
                    </Button>
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDetailDialogOpen(false)}>
                  Kapat
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
