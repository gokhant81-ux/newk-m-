import { useState } from 'react';
import { 
  Store, 
  Bell, 
  Database,
  Save,
  Mail,
  Phone,
  Clock,
  CreditCard,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useStore } from '@/hooks/useStore';
import { toast } from 'sonner';

export function SettingsPage() {
  const { settings, updateSettings } = useStore();
  
  const [shopForm, setShopForm] = useState({
    name: settings.name,
    phone: settings.phone,
    email: settings.email,
    address: settings.address,
    taxNumber: settings.taxNumber || '',
    workingHours: {
      open: settings.workingHours.open,
      close: settings.workingHours.close,
    },
  });

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    smsNotifications: false,
    orderUpdates: true,
    paymentReminders: true,
    dailySummary: true,
  });

  const handleSaveShopSettings = () => {
    updateSettings(shopForm);
    toast.success('Dükkan bilgileri kaydedildi');
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Ayarlar</h1>
        <p className="text-slate-500">Sistem ve uygulama ayarları</p>
      </div>

      <Tabs defaultValue="shop" className="space-y-6">
        <TabsList className="grid grid-cols-4 w-full max-w-lg">
          <TabsTrigger value="shop">
            <Store className="w-4 h-4 mr-2" />
            Dükkan
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Bell className="w-4 h-4 mr-2" />
            Bildirimler
          </TabsTrigger>
          <TabsTrigger value="payment">
            <CreditCard className="w-4 h-4 mr-2" />
            Ödeme
          </TabsTrigger>
          <TabsTrigger value="backup">
            <Database className="w-4 h-4 mr-2" />
            Yedekleme
          </TabsTrigger>
        </TabsList>

        {/* Shop Settings */}
        <TabsContent value="shop" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Store className="w-5 h-5 text-blue-500" />
                Dükkan Bilgileri
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="shopName">Dükkan Adı</Label>
                  <Input
                    id="shopName"
                    value={shopForm.name}
                    onChange={(e) => setShopForm({ ...shopForm, name: e.target.value })}
                    placeholder="Dükkan adı"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="taxNumber">Vergi Numarası</Label>
                  <Input
                    id="taxNumber"
                    value={shopForm.taxNumber}
                    onChange={(e) => setShopForm({ ...shopForm, taxNumber: e.target.value })}
                    placeholder="Vergi numarası"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefon</Label>
                  <Input
                    id="phone"
                    value={shopForm.phone}
                    onChange={(e) => setShopForm({ ...shopForm, phone: e.target.value })}
                    placeholder="Telefon numarası"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-posta</Label>
                  <Input
                    id="email"
                    type="email"
                    value={shopForm.email}
                    onChange={(e) => setShopForm({ ...shopForm, email: e.target.value })}
                    placeholder="E-posta adresi"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Adres</Label>
                <Input
                  id="address"
                  value={shopForm.address}
                  onChange={(e) => setShopForm({ ...shopForm, address: e.target.value })}
                  placeholder="Dükkan adresi"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="openTime">Açılış Saati</Label>
                  <Input
                    id="openTime"
                    type="time"
                    value={shopForm.workingHours.open}
                    onChange={(e) => setShopForm({ 
                      ...shopForm, 
                      workingHours: { ...shopForm.workingHours, open: e.target.value }
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="closeTime">Kapanış Saati</Label>
                  <Input
                    id="closeTime"
                    type="time"
                    value={shopForm.workingHours.close}
                    onChange={(e) => setShopForm({ 
                      ...shopForm, 
                      workingHours: { ...shopForm.workingHours, close: e.target.value }
                    })}
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button 
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={handleSaveShopSettings}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Kaydet
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification Settings */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-blue-500" />
                Bildirim Ayarları
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-slate-500" />
                    <div>
                      <p className="font-medium text-slate-800">E-posta Bildirimleri</p>
                      <p className="text-sm text-slate-500">Önemli olaylar için e-posta al</p>
                    </div>
                  </div>
                  <Switch
                    checked={notificationSettings.emailNotifications}
                    onCheckedChange={(v) => setNotificationSettings({ ...notificationSettings, emailNotifications: v })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-slate-500" />
                    <div>
                      <p className="font-medium text-slate-800">SMS Bildirimleri</p>
                      <p className="text-sm text-slate-500">Müşterilere SMS gönder</p>
                    </div>
                  </div>
                  <Switch
                    checked={notificationSettings.smsNotifications}
                    onCheckedChange={(v) => setNotificationSettings({ ...notificationSettings, smsNotifications: v })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-slate-500" />
                    <div>
                      <p className="font-medium text-slate-800">Sipariş Güncellemeleri</p>
                      <p className="text-sm text-slate-500">Sipariş durumu değişikliklerini bildir</p>
                    </div>
                  </div>
                  <Switch
                    checked={notificationSettings.orderUpdates}
                    onCheckedChange={(v) => setNotificationSettings({ ...notificationSettings, orderUpdates: v })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-slate-500" />
                    <div>
                      <p className="font-medium text-slate-800">Ödeme Hatırlatmaları</p>
                      <p className="text-sm text-slate-500">Borçlu müşterilere hatırlatma gönder</p>
                    </div>
                  </div>
                  <Switch
                    checked={notificationSettings.paymentReminders}
                    onCheckedChange={(v) => setNotificationSettings({ ...notificationSettings, paymentReminders: v })}
                  />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Bell className="w-5 h-5 text-slate-500" />
                    <div>
                      <p className="font-medium text-slate-800">Günlük Özet</p>
                      <p className="text-sm text-slate-500">Her gün özet rapor al</p>
                    </div>
                  </div>
                  <Switch
                    checked={notificationSettings.dailySummary}
                    onCheckedChange={(v) => setNotificationSettings({ ...notificationSettings, dailySummary: v })}
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button 
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={() => toast.success('Bildirim ayarları kaydedildi')}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Kaydet
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payment Settings */}
        <TabsContent value="payment" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-blue-500" />
                Ödeme Ayarları
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h4 className="font-medium text-slate-800">Kabul Edilen Ödeme Yöntemleri</h4>
                
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <span className="text-green-600 font-bold">₺</span>
                    </div>
                    <div>
                      <p className="font-medium text-slate-800">Nakit</p>
                      <p className="text-sm text-slate-500">Nakit ödeme kabul et</p>
                    </div>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <CreditCard className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-800">Kredi Kartı</p>
                      <p className="text-sm text-slate-500">Kredi kartı ödemesi kabul et</p>
                    </div>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <CreditCard className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-800">Banka Kartı</p>
                      <p className="text-sm text-slate-500">Banka kartı ödemesi kabul et</p>
                    </div>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                      <span className="text-amber-600 font-bold">H</span>
                    </div>
                    <div>
                      <p className="font-medium text-slate-800">Havale/EFT</p>
                      <p className="text-sm text-slate-500">Havale/EFT ödemesi kabul et</p>
                    </div>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>

              <div className="flex justify-end">
                <Button 
                  className="bg-blue-600 hover:bg-blue-700"
                  onClick={() => toast.success('Ödeme ayarları kaydedildi')}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Kaydet
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Backup Settings */}
        <TabsContent value="backup" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5 text-blue-500" />
                Veri Yedekleme
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-700">
                  Verileriniz otomatik olarak tarayıcınızda saklanmaktadır. 
                  Manuel yedekleme yaparak verilerinizi dışa aktarabilirsiniz.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <p className="font-medium text-slate-800">Verileri Dışa Aktar</p>
                    <p className="text-sm text-slate-500">Tüm verileri JSON formatında indir</p>
                  </div>
                  <Button variant="outline" onClick={() => toast.success('Veriler dışa aktarılıyor...')}>
                    İndir
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <p className="font-medium text-slate-800">Verileri İçe Aktar</p>
                    <p className="text-sm text-slate-500">Önceden yedeklenen verileri yükle</p>
                  </div>
                  <Button variant="outline" onClick={() => toast.success('Veri içe aktarma başlatıldı...')}>
                    Yükle
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                  <div>
                    <p className="font-medium text-slate-800">Otomatik Yedekleme</p>
                    <p className="text-sm text-slate-500">Her gün otomatik yedekle</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
