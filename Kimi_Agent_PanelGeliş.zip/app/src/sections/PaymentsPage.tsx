import { useState, useMemo } from 'react';
import { 
  Search, 
  Plus, 
  TrendingUp,
  TrendingDown,
  DollarSign,
  CreditCard,
  User,
  Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useStore } from '@/hooks/useStore';
import { formatCurrency, formatDate, getPaymentMethodLabel } from '@/lib/utils';
import { toast } from 'sonner';

import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

export function PaymentsPage() {
  const { payments, customers, orders, addPayment } = useStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  
  const [paymentForm, setPaymentForm] = useState({
    customerId: '',
    orderId: '',
    amount: 0,
    paymentMethod: 'cash' as const,
    description: '',
  });

  // Stats
  const stats = useMemo(() => {
    const today = new Date().toDateString();
    const todayPayments = payments.filter(p => new Date(p.createdAt).toDateString() === today);
    
    const totalIncome = payments.reduce((sum, p) => sum + p.amount, 0);
    const todayIncome = todayPayments.reduce((sum, p) => sum + p.amount, 0);
    
    const pendingAmount = customers.reduce((sum, c) => sum + (c.balance > 0 ? c.balance : 0), 0);
    
    return {
      totalIncome,
      todayIncome,
      pendingAmount,
      totalTransactions: payments.length,
    };
  }, [payments, customers]);

  // Filtered payments
  const filteredPayments = useMemo(() => {
    let result = [...payments].sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    if (activeTab === 'today') {
      const today = new Date().toDateString();
      result = result.filter(p => new Date(p.createdAt).toDateString() === today);
    }
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(p => 
        p.customerName.toLowerCase().includes(query) ||
        p.description?.toLowerCase().includes(query)
      );
    }
    
    return result;
  }, [payments, activeTab, searchQuery]);

  // Customers with balance
  const customersWithBalance = useMemo(() => {
    return customers
      .filter(c => c.balance > 0)
      .sort((a, b) => b.balance - a.balance);
  }, [customers]);

  const handleAddPayment = () => {
    if (!paymentForm.customerId || paymentForm.amount <= 0) {
      toast.error('Lütfen müşteri ve tutar girin');
      return;
    }

    const customer = customers.find(c => c.id === paymentForm.customerId);
    if (!customer) return;

    addPayment({
      customerId: customer.id,
      customerName: `${customer.firstName} ${customer.lastName}`,
      orderId: paymentForm.orderId || undefined,
      amount: paymentForm.amount,
      paymentMethod: paymentForm.paymentMethod,
      description: paymentForm.description,
    });

    toast.success('Ödeme başarıyla kaydedildi');
    setIsPaymentDialogOpen(false);
    resetPaymentForm();
  };

  const resetPaymentForm = () => {
    setPaymentForm({
      customerId: '',
      orderId: '',
      amount: 0,
      paymentMethod: 'cash',
      description: '',
    });
  };

  // Get customer's unpaid orders
  const getCustomerOrders = (customerId: string) => {
    return orders.filter(o => o.customerId === customerId && o.remainingAmount > 0);
  };

  const selectedCustomerOrders = paymentForm.customerId 
    ? getCustomerOrders(paymentForm.customerId)
    : [];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Ödemeler</h1>
          <p className="text-slate-500">Tahsilat ve ödeme takibi</p>
        </div>
        <Button 
          className="bg-blue-600 hover:bg-blue-700"
          onClick={() => {
            resetPaymentForm();
            setIsPaymentDialogOpen(true);
          }}
        >
          <Plus className="w-4 h-4 mr-2" />
          Tahsilat Yap
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Bugünkü Tahsilat</p>
                <h3 className="text-2xl font-bold text-slate-800 mt-1">{formatCurrency(stats.todayIncome)}</h3>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Toplam Tahsilat</p>
                <h3 className="text-2xl font-bold text-slate-800 mt-1">{formatCurrency(stats.totalIncome)}</h3>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Bekleyen Tahsilat</p>
                <h3 className="text-2xl font-bold text-red-600 mt-1">{formatCurrency(stats.pendingAmount)}</h3>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                <TrendingDown className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">İşlem Sayısı</p>
                <h3 className="text-2xl font-bold text-slate-800 mt-1">{stats.totalTransactions}</h3>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Payments List */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Ödeme Geçmişi</CardTitle>
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList>
                    <TabsTrigger value="all">Tümü</TabsTrigger>
                    <TabsTrigger value="today">Bugün</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="p-4 border-b">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <Input
                    placeholder="Ödeme ara..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50">
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Tarih</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Müşteri</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Tutar</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Ödeme Yöntemi</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Açıklama</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredPayments.map((payment) => (
                      <tr key={payment.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2 text-sm text-slate-600">
                            <Calendar className="w-4 h-4" />
                            {formatDate(payment.createdAt)}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                              <User className="w-4 h-4 text-blue-600" />
                            </div>
                            <span className="font-medium text-slate-800">{payment.customerName}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-medium text-green-600">+{formatCurrency(payment.amount)}</span>
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant="outline">
                            {getPaymentMethodLabel(payment.paymentMethod)}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-sm text-slate-500">
                          {payment.description || '-'}
                        </td>
                      </tr>
                    ))}
                    {filteredPayments.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-slate-400">
                          Henüz ödeme kaydı bulunmuyor
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Customers with Balance */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingDown className="w-5 h-5 text-red-500" />
                Borçlu Müşteriler
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50">
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Müşteri</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Borç</th>
                    </tr>
                  </thead>
                  <tbody>
                    {customersWithBalance.map((customer) => (
                      <tr key={customer.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                              <span className="text-red-600 text-sm font-medium">
                                {customer.firstName[0]}{customer.lastName[0]}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-slate-800">{customer.firstName} {customer.lastName}</p>
                              <p className="text-sm text-slate-500">{customer.phone}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-medium text-red-600">{formatCurrency(customer.balance)}</span>
                        </td>
                      </tr>
                    ))}
                    {customersWithBalance.length === 0 && (
                      <tr>
                        <td colSpan={2} className="py-8 text-center text-slate-400">
                          Borçlu müşteri bulunmuyor
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Add Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Tahsilat Yap</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Müşteri *</Label>
              <Select 
                value={paymentForm.customerId} 
                onValueChange={(v) => setPaymentForm({ ...paymentForm, customerId: v, orderId: '' })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Müşteri seçin" />
                </SelectTrigger>
                <SelectContent>
                  {customers.filter(c => c.balance > 0).map((customer) => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.firstName} {customer.lastName} - Borç: {formatCurrency(customer.balance)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedCustomerOrders.length > 0 && (
              <div className="space-y-2">
                <Label>Sipariş (İsteğe Bağlı)</Label>
                <Select 
                  value={paymentForm.orderId} 
                  onValueChange={(v) => setPaymentForm({ ...paymentForm, orderId: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sipariş seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Genel ödeme</SelectItem>
                    {selectedCustomerOrders.map((order) => (
                      <SelectItem key={order.id} value={order.id}>
                        #{order.orderNumber} - Kalan: {formatCurrency(order.remainingAmount)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-2">
              <Label>Tutar (₺) *</Label>
              <Input
                type="number"
                min={1}
                value={paymentForm.amount}
                onChange={(e) => setPaymentForm({ ...paymentForm, amount: parseInt(e.target.value) || 0 })}
                placeholder="0"
              />
            </div>

            <div className="space-y-2">
              <Label>Ödeme Yöntemi</Label>
              <Select 
                value={paymentForm.paymentMethod} 
                onValueChange={(v: any) => setPaymentForm({ ...paymentForm, paymentMethod: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Nakit</SelectItem>
                  <SelectItem value="credit_card">Kredi Kartı</SelectItem>
                  <SelectItem value="debit_card">Banka Kartı</SelectItem>
                  <SelectItem value="transfer">Havale/EFT</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Açıklama</Label>
              <Input
                value={paymentForm.description}
                onChange={(e) => setPaymentForm({ ...paymentForm, description: e.target.value })}
                placeholder="Ödeme açıklaması..."
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)}>
              İptal
            </Button>
            <Button 
              className="bg-blue-600 hover:bg-blue-700" 
              onClick={handleAddPayment}
              disabled={!paymentForm.customerId || paymentForm.amount <= 0}
            >
              Tahsilat Kaydet
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
