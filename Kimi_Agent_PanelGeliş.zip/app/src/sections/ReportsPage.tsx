import { useState, useMemo } from 'react';
import { 
  Download, 
  Calendar, 
  TrendingUp, 
  Users, 
  ShoppingBag,
  DollarSign,
  BarChart3,
  PieChart as PieChartIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useStore } from '@/hooks/useStore';
import { formatCurrency, getStatusLabel } from '@/lib/utils';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { toast } from 'sonner';

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

export function ReportsPage() {
  const { orders, customers, payments } = useStore();
  const [dateRange, setDateRange] = useState('30');

  // Calculate date range
  const getStartDate = () => {
    const days = parseInt(dateRange);
    const date = new Date();
    date.setDate(date.getDate() - days);
    return date;
  };

  const filteredOrders = useMemo(() => {
    const startDate = getStartDate();
    return orders.filter(o => new Date(o.createdAt) >= startDate);
  }, [orders, dateRange]);

  const filteredPayments = useMemo(() => {
    const startDate = getStartDate();
    return payments.filter(p => new Date(p.createdAt) >= startDate);
  }, [payments, dateRange]);

  // Revenue stats
  const revenueStats = useMemo(() => {
    const totalRevenue = filteredOrders.reduce((sum, o) => sum + o.finalAmount, 0);
    const totalOrders = filteredOrders.length;
    const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
    const totalCollected = filteredPayments.reduce((sum, p) => sum + p.amount, 0);
    
    return {
      totalRevenue,
      totalOrders,
      avgOrderValue,
      totalCollected,
      pendingAmount: totalRevenue - totalCollected,
    };
  }, [filteredOrders, filteredPayments]);

  // Daily revenue data
  const dailyRevenueData = useMemo(() => {
    const days = parseInt(dateRange);
    const data = [];
    
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toDateString();
      
      const dayOrders = orders.filter(o => new Date(o.createdAt).toDateString() === dateStr);
      const dayRevenue = dayOrders.reduce((sum, o) => sum + o.finalAmount, 0);
      
      data.push({
        date: date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' }),
        revenue: dayRevenue,
        orders: dayOrders.length,
      });
    }
    
    return data;
  }, [orders, dateRange]);

  // Service popularity
  const serviceStats = useMemo(() => {
    const serviceCount: Record<string, { name: string; count: number; revenue: number }> = {};
    
    filteredOrders.forEach(order => {
      order.items.forEach(item => {
        if (!serviceCount[item.serviceId]) {
          serviceCount[item.serviceId] = {
            name: item.serviceName,
            count: 0,
            revenue: 0,
          };
        }
        serviceCount[item.serviceId].count += item.quantity;
        serviceCount[item.serviceId].revenue += item.totalPrice;
      });
    });
    
    return Object.values(serviceCount)
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [filteredOrders]);

  // Order status distribution
  const statusDistribution = useMemo(() => {
    const distribution: Record<string, number> = {};
    
    filteredOrders.forEach(order => {
      const label = getStatusLabel(order.status);
      distribution[label] = (distribution[label] || 0) + 1;
    });
    
    return Object.entries(distribution).map(([name, value]) => ({ name, value }));
  }, [filteredOrders]);

  // Customer stats
  const customerStats = useMemo(() => {
    const newCustomers = customers.filter(c => {
      const createdAt = new Date(c.createdAt);
      return createdAt >= getStartDate();
    }).length;
    
    const topCustomers = [...customers]
      .sort((a, b) => b.totalSpent - a.totalSpent)
      .slice(0, 10);
    
    return {
      newCustomers,
      topCustomers,
    };
  }, [customers, dateRange]);

  // Payment method distribution
  const paymentMethodStats = useMemo(() => {
    const distribution: Record<string, number> = {};
    
    filteredPayments.forEach(payment => {
      const method = payment.paymentMethod;
      distribution[method] = (distribution[method] || 0) + payment.amount;
    });
    
    return Object.entries(distribution).map(([method, amount]) => ({
      name: method === 'cash' ? 'Nakit' : 
            method === 'credit_card' ? 'Kredi Kartı' :
            method === 'debit_card' ? 'Banka Kartı' : 'Havale/EFT',
      value: amount,
    }));
  }, [filteredPayments]);

  const handleExport = () => {
    toast.success('Rapor dışa aktarılıyor...');
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Raporlar</h1>
          <p className="text-slate-500">Detaylı işletme analizleri</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-40">
              <Calendar className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Son 7 Gün</SelectItem>
              <SelectItem value="30">Son 30 Gün</SelectItem>
              <SelectItem value="90">Son 3 Ay</SelectItem>
              <SelectItem value="365">Son 1 Yıl</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={handleExport}>
            <Download className="w-4 h-4 mr-2" />
            Dışa Aktar
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Toplam Ciro</p>
                <h3 className="text-2xl font-bold text-slate-800 mt-1">
                  {formatCurrency(revenueStats.totalRevenue)}
                </h3>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Sipariş Sayısı</p>
                <h3 className="text-2xl font-bold text-slate-800 mt-1">
                  {revenueStats.totalOrders}
                </h3>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <ShoppingBag className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Ortalama Sipariş</p>
                <h3 className="text-2xl font-bold text-slate-800 mt-1">
                  {formatCurrency(revenueStats.avgOrderValue)}
                </h3>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">Yeni Müşteri</p>
                <h3 className="text-2xl font-bold text-slate-800 mt-1">
                  {customerStats.newCustomers}
                </h3>
              </div>
              <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <Tabs defaultValue="revenue" className="space-y-6">
        <TabsList>
          <TabsTrigger value="revenue">
            <BarChart3 className="w-4 h-4 mr-2" />
            Ciro Analizi
          </TabsTrigger>
          <TabsTrigger value="services">
            <PieChartIcon className="w-4 h-4 mr-2" />
            Hizmetler
          </TabsTrigger>
          <TabsTrigger value="customers">
            <Users className="w-4 h-4 mr-2" />
            Müşteriler
          </TabsTrigger>
          <TabsTrigger value="payments">
            <DollarSign className="w-4 h-4 mr-2" />
            Ödemeler
          </TabsTrigger>
        </TabsList>

        {/* Revenue Tab */}
        <TabsContent value="revenue" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Günlük Ciro</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dailyRevenueData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                    <XAxis dataKey="date" stroke="#64748B" fontSize={12} />
                    <YAxis 
                      stroke="#64748B" 
                      fontSize={12}
                      tickFormatter={(value) => `₺${value}`}
                    />
                    <Tooltip 
                      formatter={(value: number) => formatCurrency(value)}
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #E2E8F0',
                        borderRadius: '8px'
                      }}
                    />
                    <Bar dataKey="revenue" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Sipariş Durumları</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={statusDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {statusDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Ciro Özeti</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Toplam Ciro</span>
                  <span className="font-bold text-slate-800">{formatCurrency(revenueStats.totalRevenue)}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Tahsil Edilen</span>
                  <span className="font-bold text-green-600">{formatCurrency(revenueStats.totalCollected)}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <span className="text-slate-600">Bekleyen</span>
                  <span className="font-bold text-red-600">{formatCurrency(revenueStats.pendingAmount)}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Services Tab */}
        <TabsContent value="services" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>En Popüler Hizmetler</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={serviceStats} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                    <XAxis type="number" stroke="#64748B" fontSize={12} />
                    <YAxis dataKey="name" type="category" stroke="#64748B" fontSize={12} width={150} />
                    <Tooltip 
                      formatter={(value: number, name: string) => {
                        if (name === 'revenue') return formatCurrency(value);
                        return value;
                      }}
                      contentStyle={{ 
                        backgroundColor: 'white', 
                        border: '1px solid #E2E8F0',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Bar dataKey="count" name="Adet" fill="#3B82F6" radius={[0, 4, 4, 0]} />
                    <Bar dataKey="revenue" name="Ciro" fill="#10B981" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Hizmet Detayları</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-100">
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Hizmet</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Adet</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Ciro</th>
                    </tr>
                  </thead>
                  <tbody>
                    {serviceStats.map((service, idx) => (
                      <tr key={idx} className="border-b border-slate-50">
                        <td className="py-3 px-4 font-medium text-slate-800">{service.name}</td>
                        <td className="py-3 px-4">{service.count}</td>
                        <td className="py-3 px-4 font-medium text-green-600">{formatCurrency(service.revenue)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Customers Tab */}
        <TabsContent value="customers" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>En Değerli Müşteriler</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50">
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Müşteri</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Sipariş</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Toplam Harcama</th>
                      <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Bakiye</th>
                    </tr>
                  </thead>
                  <tbody>
                    {customerStats.topCustomers.map((customer) => (
                      <tr key={customer.id} className="border-b border-slate-50 hover:bg-slate-50">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <span className="text-blue-600 font-medium">
                                {customer.firstName[0]}{customer.lastName[0]}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-slate-800">{customer.firstName} {customer.lastName}</p>
                              <p className="text-sm text-slate-500">{customer.phone}</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4">{customer.totalOrders}</td>
                        <td className="py-3 px-4 font-medium text-green-600">{formatCurrency(customer.totalSpent)}</td>
                        <td className="py-3 px-4">
                          <span className={customer.balance > 0 ? 'text-red-600' : 'text-green-600'}>
                            {formatCurrency(customer.balance)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payments Tab */}
        <TabsContent value="payments" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Ödeme Yöntemleri</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={paymentMethodStats}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {paymentMethodStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => formatCurrency(value)} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Ödeme Özeti</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {paymentMethodStats.map((method, idx) => (
                  <div key={idx} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-600">{method.name}</span>
                    <span className="font-bold text-slate-800">{formatCurrency(method.value)}</span>
                  </div>
                ))}
                {paymentMethodStats.length === 0 && (
                  <p className="text-center text-slate-400 py-8">Henüz ödeme verisi bulunmuyor</p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
