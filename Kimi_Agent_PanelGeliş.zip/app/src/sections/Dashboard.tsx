import { useEffect, useState } from 'react';
import { 
  ShoppingBag, 
  Clock, 
  TrendingUp, 
  AlertCircle,
  ArrowUpRight,
  ArrowDownRight,
  MoreHorizontal
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useStore } from '@/hooks/useStore';
import { formatCurrency, formatDate, getStatusLabel, getStatusColor } from '@/lib/utils';
import type { OrderStatus } from '@/types';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';

interface StatCardProps {
  title: string;
  value: string | number;
  description: string;
  icon: React.ElementType;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  color: string;
}

function StatCard({ title, value, description, icon: Icon, trend, trendValue, color }: StatCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow duration-300">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <p className="text-sm font-medium text-slate-500">{title}</p>
            <h3 className="text-2xl font-bold text-slate-800 mt-1">{value}</h3>
            <div className="flex items-center gap-2 mt-2">
              {trend && trend !== 'neutral' && (
                <span className={`flex items-center text-xs font-medium ${
                  trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {trend === 'up' ? <ArrowUpRight className="w-3 h-3 mr-0.5" /> : <ArrowDownRight className="w-3 h-3 mr-0.5" />}
                  {trendValue}
                </span>
              )}
              <span className="text-xs text-slate-400">{description}</span>
            </div>
          </div>
          <div className={`w-12 h-12 ${color} rounded-xl flex items-center justify-center`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

const statusColors: Record<OrderStatus, string> = {
  pending: '#F59E0B',
  washing: '#3B82F6',
  ironing: '#8B5CF6',
  ready: '#10B981',
  delivered: '#22C55E',
  cancelled: '#EF4444',
};

const weekDays = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];
const months = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz'];

export function Dashboard() {
  const { getDashboardStats, orders, customers } = useStore();
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    setStats(getDashboardStats());
  }, [orders, customers]);

  if (!stats) return null;

  // Prepare chart data
  const orderStatusData = Object.entries(stats.ordersByStatus)
    .filter(([_, count]) => count > 0)
    .map(([status, count]) => ({
      name: getStatusLabel(status as OrderStatus),
      value: count,
      color: statusColors[status as OrderStatus],
    }));

  const weeklyData = stats.weeklyRevenue.map((revenue: number, index: number) => ({
    day: weekDays[index],
    revenue,
  }));

  const monthlyData = stats.monthlyRevenue.map((revenue: number, index: number) => ({
    month: months[index],
    revenue,
  }));

  // Recent orders
  const recentOrders = [...orders]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 10);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Dashboard</h1>
          <p className="text-slate-500">İşletmenizin genel durumu</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <ShoppingBag className="w-4 h-4 mr-2" />
          Yeni Sipariş
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Bugünkü Siparişler"
          value={stats.todayOrders}
          description="bugün"
          icon={ShoppingBag}
          trend="up"
          trendValue="12%"
          color="bg-blue-500"
        />
        <StatCard
          title="Aktif Siparişler"
          value={stats.activeOrders}
          description="işlemde"
          icon={Clock}
          color="bg-amber-500"
        />
        <StatCard
          title="Bugünkü Ciro"
          value={formatCurrency(stats.todayRevenue)}
          description="bugün"
          icon={TrendingUp}
          trend="up"
          trendValue="8%"
          color="bg-green-500"
        />
        <StatCard
          title="Bekleyen Tahsilat"
          value={formatCurrency(stats.pendingPayments)}
          description="toplam borç"
          icon={AlertCircle}
          trend="down"
          trendValue="5%"
          color="bg-red-500"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Revenue Chart */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-semibold">Haftalık Ciro</CardTitle>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis dataKey="day" stroke="#64748B" fontSize={12} />
                  <YAxis 
                    stroke="#64748B" 
                    fontSize={12}
                    tickFormatter={(value) => `₺${value}`}
                  />
                  <Tooltip 
                    formatter={(value: number) => formatCurrency(value)}
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #E2E8F0',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar 
                    dataKey="revenue" 
                    fill="#3B82F6" 
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Order Status Distribution */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-semibold">Sipariş Durumları</CardTitle>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={orderStatusData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {orderStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-col gap-2 ml-4">
                {orderStatusData.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-sm text-slate-600">{item.name}</span>
                    <span className="text-sm font-medium text-slate-800">({item.value})</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Trend & Top Services */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Monthly Revenue */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-lg font-semibold">Aylık Ciro Trendi</CardTitle>
            <Button variant="ghost" size="sm">
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis dataKey="month" stroke="#64748B" fontSize={12} />
                  <YAxis 
                    stroke="#64748B" 
                    fontSize={12}
                    tickFormatter={(value) => `₺${value}`}
                  />
                  <Tooltip 
                    formatter={(value: number) => formatCurrency(value)}
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #E2E8F0',
                      borderRadius: '8px'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#3B82F6" 
                    strokeWidth={3}
                    dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Top Services */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold">Popüler Hizmetler</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stats.topServices.map((service: any, index: number) => (
                <div key={service.name}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-slate-600">{service.name}</span>
                    <span className="text-sm font-medium text-slate-800">{service.count} adet</span>
                  </div>
                  <Progress 
                    value={(service.count / stats.topServices[0].count) * 100} 
                    className="h-2"
                  />
                </div>
              ))}
              {stats.topServices.length === 0 && (
                <p className="text-sm text-slate-400 text-center py-4">
                  Henüz veri bulunmuyor
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Orders Table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg font-semibold">Son Siparişler</CardTitle>
          <Button variant="outline" size="sm">
            Tümünü Gör
          </Button>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-100">
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Sipariş No</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Müşteri</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Tutar</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Durum</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-slate-500">Tarih</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((order) => (
                  <tr key={order.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-800">#{order.orderNumber}</span>
                    </td>
                    <td className="py-3 px-4">
                      <div>
                        <p className="font-medium text-slate-800">{order.customerName}</p>
                        <p className="text-sm text-slate-500">{order.customerPhone}</p>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-800">{formatCurrency(order.finalAmount)}</span>
                    </td>
                    <td className="py-3 px-4">
                      <Badge className={getStatusColor(order.status)}>
                        {getStatusLabel(order.status)}
                      </Badge>
                    </td>
                    <td className="py-3 px-4 text-sm text-slate-500">
                      {formatDate(order.createdAt)}
                    </td>
                  </tr>
                ))}
                {recentOrders.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400">
                      Henüz sipariş bulunmuyor
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
