import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Customer, Service, Order, Payment, User, ShopSettings, OrderStatus } from '@/types';

interface StoreState {
  // Auth
  currentUser: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => boolean;
  logout: () => void;

  // Customers
  customers: Customer[];
  addCustomer: (customer: Omit<Customer, 'id' | 'createdAt' | 'totalOrders' | 'totalSpent' | 'balance'>) => Customer;
  updateCustomer: (id: string, data: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;
  getCustomerById: (id: string) => Customer | undefined;
  searchCustomers: (query: string) => Customer[];

  // Services
  services: Service[];
  addService: (service: Omit<Service, 'id'>) => Service;
  updateService: (id: string, data: Partial<Service>) => void;
  deleteService: (id: string) => void;
  getActiveServices: () => Service[];

  // Orders
  orders: Order[];
  addOrder: (order: Omit<Order, 'id' | 'orderNumber' | 'createdAt'>) => Order;
  updateOrder: (id: string, data: Partial<Order>) => void;
  deleteOrder: (id: string) => void;
  updateOrderStatus: (id: string, status: OrderStatus) => void;
  getOrdersByStatus: (status: OrderStatus) => Order[];
  getCustomerOrders: (customerId: string) => Order[];
  getTodayOrders: () => Order[];
  getActiveOrders: () => Order[];
  generateOrderNumber: () => string;

  // Payments
  payments: Payment[];
  addPayment: (payment: Omit<Payment, 'id' | 'createdAt'>) => Payment;
  getCustomerPayments: (customerId: string) => Payment[];
  getTodayPayments: () => Payment[];

  // Settings
  settings: ShopSettings;
  updateSettings: (settings: Partial<ShopSettings>) => void;

  // Stats
  getDashboardStats: () => {
    todayOrders: number;
    activeOrders: number;
    todayRevenue: number;
    pendingPayments: number;
    ordersByStatus: Record<OrderStatus, number>;
    weeklyRevenue: number[];
    monthlyRevenue: number[];
    topServices: { name: string; count: number }[];
  };
}

const generateId = () => Math.random().toString(36).substring(2, 15);

const initialServices: Service[] = [
  { id: generateId(), name: 'Gömlek Yıkama', category: 'Yıkama', price: 25, unit: 'adet', description: 'Standart gömlek yıkama', isActive: true, estimatedDays: 1 },
  { id: generateId(), name: 'Pantolon Yıkama', category: 'Yıkama', price: 35, unit: 'adet', description: 'Pantolon yıkama ve ütü', isActive: true, estimatedDays: 1 },
  { id: generateId(), name: 'Ceket/Kaban Yıkama', category: 'Yıkama', price: 75, unit: 'adet', description: 'Kışlık mont ve kaban yıkama', isActive: true, estimatedDays: 2 },
  { id: generateId(), name: 'Elbise Yıkama', category: 'Yıkama', price: 60, unit: 'adet', description: 'Kadın elbisesi yıkama', isActive: true, estimatedDays: 1 },
  { id: generateId(), name: 'Takım Elbise', category: 'Kuru Temizleme', price: 150, unit: 'adet', description: 'Takım elbise kuru temizleme', isActive: true, estimatedDays: 2 },
  { id: generateId(), name: 'Gelinlik', category: 'Kuru Temizleme', price: 500, unit: 'adet', description: 'Gelinlik özel temizleme', isActive: true, estimatedDays: 5 },
  { id: generateId(), name: 'Perde Yıkama', category: 'Ev Tekstili', price: 45, unit: 'metre', description: 'Perde yıkama ve ütü', isActive: true, estimatedDays: 2 },
  { id: generateId(), name: 'Halı Yıkama', category: 'Ev Tekstili', price: 35, unit: 'metre', description: 'Halı yıkama', isActive: true, estimatedDays: 3 },
  { id: generateId(), name: 'Yorgan Yıkama', category: 'Ev Tekstili', price: 80, unit: 'adet', description: 'Yorgan yıkama', isActive: true, estimatedDays: 3 },
  { id: generateId(), name: 'Nevresim Takımı', category: 'Ev Tekstili', price: 65, unit: 'adet', description: 'Nevresim takımı yıkama', isActive: true, estimatedDays: 2 },
];

const initialSettings: ShopSettings = {
  name: 'Kuru Temizleme Pro',
  phone: '0 (212) 555 00 00',
  email: 'info@kurutemizlemepro.com',
  address: 'Örnek Mahallesi, Örnek Sokak No:1, İstanbul',
  workingHours: { open: '08:00', close: '20:00' },
};

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      // Auth
      currentUser: null,
      isAuthenticated: false,
      login: (email, password) => {
        if (email === 'admin@admin.com' && password === 'admin123') {
          set({
            currentUser: {
              id: '1',
              name: 'Admin',
              email: 'admin@admin.com',
              role: 'admin',
              isActive: true,
              createdAt: new Date().toISOString(),
            },
            isAuthenticated: true,
          });
          return true;
        }
        return false;
      },
      logout: () => {
        set({ currentUser: null, isAuthenticated: false });
      },

      // Customers
      customers: [],
      addCustomer: (customerData) => {
        const customer: Customer = {
          ...customerData,
          id: generateId(),
          createdAt: new Date().toISOString(),
          totalOrders: 0,
          totalSpent: 0,
          balance: 0,
        };
        set((state) => ({ customers: [...state.customers, customer] }));
        return customer;
      },
      updateCustomer: (id, data) => {
        set((state) => ({
          customers: state.customers.map((c) => (c.id === id ? { ...c, ...data } : c)),
        }));
      },
      deleteCustomer: (id) => {
        set((state) => ({
          customers: state.customers.filter((c) => c.id !== id),
        }));
      },
      getCustomerById: (id) => {
        return get().customers.find((c) => c.id === id);
      },
      searchCustomers: (query) => {
        const lowerQuery = query.toLowerCase();
        return get().customers.filter(
          (c) =>
            c.firstName.toLowerCase().includes(lowerQuery) ||
            c.lastName.toLowerCase().includes(lowerQuery) ||
            c.phone.includes(query)
        );
      },

      // Services
      services: initialServices,
      addService: (serviceData) => {
        const service: Service = { ...serviceData, id: generateId() };
        set((state) => ({ services: [...state.services, service] }));
        return service;
      },
      updateService: (id, data) => {
        set((state) => ({
          services: state.services.map((s) => (s.id === id ? { ...s, ...data } : s)),
        }));
      },
      deleteService: (id) => {
        set((state) => ({
          services: state.services.filter((s) => s.id !== id),
        }));
      },
      getActiveServices: () => {
        return get().services.filter((s) => s.isActive);
      },

      // Orders
      orders: [],
      addOrder: (orderData) => {
        const order: Order = {
          ...orderData,
          id: generateId(),
          orderNumber: get().generateOrderNumber(),
          createdAt: new Date().toISOString(),
        };
        set((state) => {
          // Update customer stats
          const customer = state.customers.find((c) => c.id === order.customerId);
          if (customer) {
            customer.totalOrders += 1;
            customer.totalSpent += order.finalAmount;
            customer.balance += order.remainingAmount;
          }
          return { orders: [...state.orders, order] };
        });
        return order;
      },
      updateOrder: (id, data) => {
        set((state) => ({
          orders: state.orders.map((o) => (o.id === id ? { ...o, ...data } : o)),
        }));
      },
      deleteOrder: (id) => {
        set((state) => ({
          orders: state.orders.filter((o) => o.id !== id),
        }));
      },
      updateOrderStatus: (id, status) => {
        set((state) => ({
          orders: state.orders.map((o) =>
            o.id === id
              ? {
                  ...o,
                  status,
                  deliveredAt: status === 'delivered' ? new Date().toISOString() : o.deliveredAt,
                }
              : o
          ),
        }));
      },
      getOrdersByStatus: (status) => {
        return get().orders.filter((o) => o.status === status);
      },
      getCustomerOrders: (customerId) => {
        return get().orders.filter((o) => o.customerId === customerId).sort((a, b) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
      },
      getTodayOrders: () => {
        const today = new Date().toDateString();
        return get().orders.filter((o) => new Date(o.createdAt).toDateString() === today);
      },
      getActiveOrders: () => {
        return get().orders.filter((o) => 
          ['pending', 'washing', 'ironing', 'ready'].includes(o.status)
        );
      },
      generateOrderNumber: () => {
        const date = new Date();
        const prefix = date.getFullYear().toString().slice(-2);
        const count = get().orders.length + 1;
        return `${prefix}${String(count).padStart(5, '0')}`;
      },

      // Payments
      payments: [],
      addPayment: (paymentData) => {
        const payment: Payment = {
          ...paymentData,
          id: generateId(),
          createdAt: new Date().toISOString(),
        };
        set((state) => {
          // Update customer balance
          const customer = state.customers.find((c) => c.id === payment.customerId);
          if (customer) {
            customer.balance -= payment.amount;
          }
          // Update order paid amount
          if (payment.orderId) {
            const order = state.orders.find((o) => o.id === payment.orderId);
            if (order) {
              order.paidAmount += payment.amount;
              order.remainingAmount -= payment.amount;
            }
          }
          return { payments: [...state.payments, payment] };
        });
        return payment;
      },
      getCustomerPayments: (customerId) => {
        return get().payments.filter((p) => p.customerId === customerId);
      },
      getTodayPayments: () => {
        const today = new Date().toDateString();
        return get().payments.filter((p) => new Date(p.createdAt).toDateString() === today);
      },

      // Settings
      settings: initialSettings,
      updateSettings: (newSettings) => {
        set((state) => ({
          settings: { ...state.settings, ...newSettings },
        }));
      },

      // Stats
      getDashboardStats: () => {
        const orders = get().orders;
        const today = new Date().toDateString();
        const todayOrders = orders.filter((o) => new Date(o.createdAt).toDateString() === today);

        const ordersByStatus: Record<OrderStatus, number> = {
          pending: 0,
          washing: 0,
          ironing: 0,
          ready: 0,
          delivered: 0,
          cancelled: 0,
        };
        orders.forEach((o) => {
          ordersByStatus[o.status]++;
        });

        // Weekly revenue (last 7 days)
        const weeklyRevenue: number[] = [];
        for (let i = 6; i >= 0; i--) {
          const date = new Date();
          date.setDate(date.getDate() - i);
          const dayRevenue = orders
            .filter((o) => new Date(o.createdAt).toDateString() === date.toDateString())
            .reduce((sum, o) => sum + o.finalAmount, 0);
          weeklyRevenue.push(dayRevenue);
        }

        // Monthly revenue (last 6 months)
        const monthlyRevenue: number[] = [];
        for (let i = 5; i >= 0; i--) {
          const date = new Date();
          date.setMonth(date.getMonth() - i);
          const monthRevenue = orders
            .filter((o) => {
              const orderDate = new Date(o.createdAt);
              return orderDate.getMonth() === date.getMonth() && orderDate.getFullYear() === date.getFullYear();
            })
            .reduce((sum, o) => sum + o.finalAmount, 0);
          monthlyRevenue.push(monthRevenue);
        }

        // Top services
        const serviceCount: Record<string, number> = {};
        orders.forEach((o) => {
          o.items.forEach((item) => {
            serviceCount[item.serviceName] = (serviceCount[item.serviceName] || 0) + item.quantity;
          });
        });
        const topServices = Object.entries(serviceCount)
          .map(([name, count]) => ({ name, count }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 5);

        return {
          todayOrders: todayOrders.length,
          activeOrders: orders.filter((o) => ['pending', 'washing', 'ironing', 'ready'].includes(o.status)).length,
          todayRevenue: todayOrders.reduce((sum, o) => sum + o.finalAmount, 0),
          pendingPayments: get().customers.reduce((sum, c) => sum + (c.balance > 0 ? c.balance : 0), 0),
          ordersByStatus,
          weeklyRevenue,
          monthlyRevenue,
          topServices,
        };
      },
    }),
    {
      name: 'kuru-temizleme-storage',
    }
  )
);
