// Kuru Temizleme Yönetim Paneli - TypeScript Tipleri

export interface Customer {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  email?: string;
  address?: string;
  notes?: string;
  createdAt: string;
  totalOrders: number;
  totalSpent: number;
  balance: number;
}

export interface Service {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: 'adet' | 'kg' | 'metre';
  description?: string;
  isActive: boolean;
  estimatedDays: number;
}

export type OrderStatus = 
  | 'pending'      // Sipariş Alındı
  | 'washing'      // Yıkamada
  | 'ironing'      // Ütüde
  | 'ready'        // Hazır
  | 'delivered'    // Teslim Edildi
  | 'cancelled';   // İptal Edildi

export interface OrderItem {
  id: string;
  serviceId: string;
  serviceName: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  notes?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  items: OrderItem[];
  totalAmount: number;
  discount: number;
  finalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  status: OrderStatus;
  notes?: string;
  createdAt: string;
  promisedDate: string;
  deliveredAt?: string;
}

export interface Payment {
  id: string;
  orderId?: string;
  customerId: string;
  customerName: string;
  amount: number;
  paymentMethod: 'cash' | 'credit_card' | 'debit_card' | 'transfer';
  description?: string;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'staff';
  isActive: boolean;
  createdAt: string;
}

export interface DashboardStats {
  todayOrders: number;
  activeOrders: number;
  todayRevenue: number;
  pendingPayments: number;
  weeklyRevenue: number[];
  monthlyRevenue: number[];
  ordersByStatus: Record<OrderStatus, number>;
  topServices: { name: string; count: number }[];
}

export interface ShopSettings {
  name: string;
  phone: string;
  email: string;
  address: string;
  taxNumber?: string;
  workingHours: {
    open: string;
    close: string;
  };
}
