import { useState, useEffect } from 'react';
import { useStore } from '@/hooks/useStore';
import { LoginPage } from '@/sections/LoginPage';
import { Dashboard } from '@/sections/Dashboard';
import { Sidebar } from '@/components/Sidebar';
import { Header } from '@/components/Header';
import { CustomersPage } from '@/sections/CustomersPage';
import { OrdersPage } from '@/sections/OrdersPage';
import { ServicesPage } from '@/sections/ServicesPage';
import { PaymentsPage } from '@/sections/PaymentsPage';
import { ReportsPage } from '@/sections/ReportsPage';
import { SettingsPage } from '@/sections/SettingsPage';
import { Toaster } from '@/components/ui/sonner';

type PageType = 'dashboard' | 'customers' | 'orders' | 'services' | 'payments' | 'reports' | 'settings';

function App() {
  const { isAuthenticated } = useStore();
  const [currentPage, setCurrentPage] = useState<PageType>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Demo veri oluşturma
  useEffect(() => {
    const store = useStore.getState();
    
    // Demo müşteriler
    if (store.customers.length === 0) {
      const demoCustomers = [
        { firstName: 'Ahmet', lastName: 'Yılmaz', phone: '0532 123 45 67', email: 'ahmet@email.com', address: 'Kadıköy, İstanbul' },
        { firstName: 'Ayşe', lastName: 'Kaya', phone: '0533 234 56 78', email: 'ayse@email.com', address: 'Beşiktaş, İstanbul' },
        { firstName: 'Mehmet', lastName: 'Demir', phone: '0534 345 67 89', email: 'mehmet@email.com', address: 'Şişli, İstanbul' },
        { firstName: 'Fatma', lastName: 'Şahin', phone: '0535 456 78 90', email: 'fatma@email.com', address: 'Üsküdar, İstanbul' },
        { firstName: 'Ali', lastName: 'Özdemir', phone: '0536 567 89 01', email: 'ali@email.com', address: 'Bakırköy, İstanbul' },
      ];
      
      demoCustomers.forEach(c => store.addCustomer(c));
    }

    // Demo siparişler
    if (store.orders.length === 0) {
      const customers = store.customers;
      const services = store.services;
      
      if (customers.length > 0 && services.length > 0) {
        const statuses = ['pending', 'washing', 'ironing', 'ready', 'delivered'] as const;
        
        for (let i = 0; i < 15; i++) {
          const customer = customers[Math.floor(Math.random() * customers.length)];
          const numItems = Math.floor(Math.random() * 3) + 1;
          const items = [];
          let totalAmount = 0;
          
          for (let j = 0; j < numItems; j++) {
            const service = services[Math.floor(Math.random() * services.length)];
            const quantity = Math.floor(Math.random() * 3) + 1;
            const totalPrice = service.price * quantity;
            totalAmount += totalPrice;
            items.push({
              id: `item-${i}-${j}`,
              serviceId: service.id,
              serviceName: service.name,
              quantity,
              unitPrice: service.price,
              totalPrice,
            });
          }
          
          const discount = Math.random() > 0.7 ? Math.floor(totalAmount * 0.1) : 0;
          const finalAmount = totalAmount - discount;
          const paidAmount = Math.random() > 0.5 ? finalAmount : Math.floor(finalAmount * 0.5);
          
          const orderDate = new Date();
          orderDate.setDate(orderDate.getDate() - Math.floor(Math.random() * 30));
          
          store.addOrder({
            customerId: customer.id,
            customerName: `${customer.firstName} ${customer.lastName}`,
            customerPhone: customer.phone,
            items,
            totalAmount,
            discount,
            finalAmount,
            paidAmount,
            remainingAmount: finalAmount - paidAmount,
            status: statuses[Math.floor(Math.random() * statuses.length)],
            promisedDate: new Date(orderDate.getTime() + 2 * 24 * 60 * 60 * 1000).toISOString(),
          });
        }
      }
    }
  }, []);

  if (!isAuthenticated) {
    return (
      <>
        <LoginPage />
        <Toaster />
      </>
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard />;
      case 'customers':
        return <CustomersPage />;
      case 'orders':
        return <OrdersPage />;
      case 'services':
        return <ServicesPage />;
      case 'payments':
        return <PaymentsPage />;
      case 'reports':
        return <ReportsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar 
        currentPage={currentPage} 
        onPageChange={setCurrentPage} 
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
      />
      <div className={`flex-1 flex flex-col transition-all duration-300 ${isSidebarOpen ? 'ml-64' : 'ml-20'}`}>
        <Header onMenuToggle={() => setIsSidebarOpen(!isSidebarOpen)} />
        <main className="flex-1 p-6 overflow-auto">
          {renderPage()}
        </main>
      </div>
      <Toaster />
    </div>
  );
}

export default App;
